﻿namespace SimuladorPC.Domain.Enums;

public enum VersaoPcie
{
    Pcie1_0 = 1,
    Pcie2_0 = 2,
    Pcie3_0 = 3,
    Pcie4_0 = 4,
    Pcie5_0 = 5,
    Pcie6_0 = 6
}
