﻿namespace SimuladorPC.Domain.Entities.Hardware;

public class TipoMemoria
{
    public int Id { get; private set; }
    public string Tipo { get; private set; }
}
