﻿namespace SimuladorPC.Data
{
    public class Class1
    {

    }
}
