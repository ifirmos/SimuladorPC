﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SimuladorPC.Data.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Componentes",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Marca = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ModelNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Descricao = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Discriminator = table.Column<string>(type: "nvarchar(13)", maxLength: 13, nullable: false),
                    Tipo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Altura = table.Column<double>(type: "float", nullable: true),
                    Largura = table.Column<double>(type: "float", nullable: true),
                    Comprimento = table.Column<double>(type: "float", nullable: true),
                    BaiasInternas = table.Column<int>(type: "int", nullable: true),
                    BaiasExternas = table.Column<int>(type: "int", nullable: true),
                    SuportePlacaMae = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Iluminacao_TemIluminacao = table.Column<bool>(type: "bit", nullable: true),
                    Iluminacao_IsRgb = table.Column<bool>(type: "bit", nullable: true),
                    Iluminacao_IsArgb = table.Column<bool>(type: "bit", nullable: true),
                    Iluminacao_CorFixa = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TemJanela = table.Column<bool>(type: "bit", nullable: true),
                    TemFiltrosDePoeira = table.Column<bool>(type: "bit", nullable: true),
                    Cor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TamanhoRadiador = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    QuantidadeFans = table.Column<int>(type: "int", nullable: true),
                    SocketsCompativeis = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Componentes", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Componentes");
        }
    }
}
