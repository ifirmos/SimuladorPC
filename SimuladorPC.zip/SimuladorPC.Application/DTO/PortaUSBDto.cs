namespace SimuladorPC.Application.DTO;

public class PortaUSBDto
{
    public string? TipoUSB { get; private set; }
    public int Quantidade { get; private set; }
    public bool Externa { get; private set; }
}
