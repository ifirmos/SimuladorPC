﻿namespace SimuladorPC.Application.DTO;

public class BaseDto
{
    public int Id { get; set; }
}

