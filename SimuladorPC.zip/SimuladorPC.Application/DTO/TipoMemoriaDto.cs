﻿namespace SimuladorPC.Application.DTO;

public class TipoMemoriaDto
{
    public int Id { get; private set; }
    public string Tipo { get; set; }
}