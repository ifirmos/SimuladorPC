namespace SimuladorPC.Application.DTO;

public class IluminacaoDto
{
    public int Id { get; set; }
    public string? TipoIluminacao { get; private set; }
    public string? CorFixa { get; private set; }
}
