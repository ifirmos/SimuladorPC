﻿namespace SimuladorPC.Application.DTO;

public class ChipsetDto
{
    public int Id { get;  private set; }
    public string Modelo { get; set; }
    public string Fabricante { get; set; }
}
