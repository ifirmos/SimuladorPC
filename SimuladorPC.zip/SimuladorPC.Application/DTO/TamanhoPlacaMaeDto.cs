﻿namespace SimuladorPC.Application.DTO;

public class TamanhoPlacaMaeDto
{
    public int Id { get; private set; }
    public string Tamanho {  get; set; }
}