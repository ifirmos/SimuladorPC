﻿namespace SimuladorPC.Application.DTO;

public class SocketProcessadorDto
{
    public int Id { get; private set; }
    public string Nome { get; set; }
}