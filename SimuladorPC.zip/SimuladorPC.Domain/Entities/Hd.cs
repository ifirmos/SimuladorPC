﻿namespace SimuladorPC.Domain.Entities;

public class Hd : Componente
{
    public int Capacidade { get; set; }
    public string Velocidade { get; set; }
}
