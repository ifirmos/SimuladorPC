﻿namespace SimuladorPC.Domain.Entities;

public class Componente
{
    public string Id {  get; set; }
    public string Marca { get; set; }
    public string ModelNumber { get; set; }
    public string Descricao { get; set; }
}