﻿namespace SimuladorPC.Domain.Entities;

public class Ram : Componente
{
    public int Capacidade { get; set; }
    public string Tipo { get; set; }
    public bool Rgb { get; set; }
}
