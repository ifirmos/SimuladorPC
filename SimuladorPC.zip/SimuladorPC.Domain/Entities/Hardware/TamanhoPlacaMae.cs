﻿namespace SimuladorPC.Domain.Entities.Hardware
{
    public class TamanhoPlacaMae
    {
        public int Id { get; private set; }
        public string Tamanho { get; private set; }
    }
}