﻿using SimuladorPC.Domain.Entities.Hardware;
using SimuladorPC.Domain.Entities.Software;
using SimuladorPC.Domain.Interfaces.Repositories;
using SimuladorPC.Domain.Interfaces.Services;

namespace SimuladorPC.Domain.Services;

public class PlacaMaeService : ComponenteService<PlacaMae>, IPlacaMaeService
{
    private readonly IPlacaMaeRepository _placaMaeRepository;
    private readonly IBaseRepository<Chipset> _chipsetRepository;
    private readonly IBaseRepository<SocketProcessador> _socketRepository;

    public PlacaMaeService(
        IPlacaMaeRepository placaMaeRepository, 
        IBaseRepository<Chipset> chipsetRepository, 
        IBaseRepository<SocketProcessador> socketRepository)
        : base(placaMaeRepository) 
    {
        _placaMaeRepository = placaMaeRepository;
        _chipsetRepository = chipsetRepository;
        _socketRepository = socketRepository;
    }

    public IEnumerable<PlacaMae> BuscarPorSocket(int socketId)
    {
        return _placaMaeRepository.BuscaPorSocket(socketId);
    }
    public IEnumerable<PlacaMae> BuscarPorChipset(int chipsetId)
    {
        return _placaMaeRepository.BuscaPorChipset(chipsetId);
    }

    public PlacaMae AdicionarPlacaMae(PlacaMae placaMae)
    {
        if (_placaMaeRepository.Any(p => p.Nome.Trim().ToLower() == placaMae.Nome.Trim().ToLower()))
        {
            throw new Exception("Uma placa mãe com o mesmo nome já existe.");
        }

        var existingChipset = _chipsetRepository.Find(c => c.Modelo == placaMae.Chipset.Modelo);
        if (existingChipset != null)
        {
            placaMae.SetChipset(existingChipset);
        }

        var existingSocket = _socketRepository.Find(s => s.Nome == placaMae.SocketProcessador.Nome);
        if (existingSocket != null)
        {
            placaMae.SetSocket(existingSocket);
        }

        _placaMaeRepository.Add(placaMae);
        return placaMae;
    }

    public IEnumerable<Cpu> ListarCpusCompativeis(int placaMaeId)
    {
        throw new NotImplementedException();
    }
}
