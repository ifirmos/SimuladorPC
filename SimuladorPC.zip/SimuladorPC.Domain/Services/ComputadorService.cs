﻿using SimuladorPC.Domain.Entities.Hardware;
using SimuladorPC.Domain.Interfaces.Services;

namespace SimuladorPC.Domain.Services;

public class ComputadorService : IComputadorService
{
}
