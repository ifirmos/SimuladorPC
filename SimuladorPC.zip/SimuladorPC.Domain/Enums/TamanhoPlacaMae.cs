﻿namespace SimuladorPC.Domain.Enums;

public enum TamanhoPlacaMae
{
    ATX,
    MicroATX,
    MiniITX
}
