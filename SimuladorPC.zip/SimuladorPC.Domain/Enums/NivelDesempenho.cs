﻿namespace SimuladorPC.Domain.Enums;

public enum NivelDesempenho
{
    Basico,
    Intermediario,
    Premium
}
