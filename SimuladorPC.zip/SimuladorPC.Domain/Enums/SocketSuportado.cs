﻿namespace SimuladorPC.Domain.Enums;

public enum SocketSuportado
{
    AM4,
    AM5,
    TR4,
    LGA1151,
    LGA1200,
    LGA1700,
}
