﻿using SimuladorPC.Domain.Entities;

namespace SimuladorPC.Domain.Interfaces.Services
{
    public class IGabineteService
    {
        public void AdicionarGabinete(Gabinete gabinete)
        {
            throw new NotImplementedException();
        }

        public object GetAllGabinetes()
        {
            throw new NotImplementedException();
        }
    }
}
