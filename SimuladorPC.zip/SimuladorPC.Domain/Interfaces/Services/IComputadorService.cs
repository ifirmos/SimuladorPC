﻿namespace SimuladorPC.Domain.Interfaces.Services;

public interface IComputadorService
{
}

