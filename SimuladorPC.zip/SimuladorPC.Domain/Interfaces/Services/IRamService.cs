﻿using SimuladorPC.Domain.Entities.Hardware;

namespace SimuladorPC.Domain.Interfaces.Services;

public interface IRamService : IComponenteService<Ram>
{

}