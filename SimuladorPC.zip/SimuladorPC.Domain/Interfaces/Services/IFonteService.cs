﻿using SimuladorPC.Domain.Entities.Hardware;

namespace SimuladorPC.Domain.Interfaces.Services;

public interface IFonteService : IComponenteService<Fonte>
{
}

