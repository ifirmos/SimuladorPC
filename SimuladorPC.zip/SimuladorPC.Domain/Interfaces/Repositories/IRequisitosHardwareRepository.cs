﻿using SimuladorPC.Domain.Entities.Software;

namespace SimuladorPC.Domain.Interfaces.Repositories;

public interface IRequisitosHardwareRepository : IBaseRepository<RequisitosHardware>
{
}
